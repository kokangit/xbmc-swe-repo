dreamfilm-xbmc
==============
Unofficial dreamfilmhd.org plugin for Kodi. Not yet published to a repository.
[![Build Status](https://travis-ci.org/daniel-lundin/dreamfilm-xbmc.svg?branch=v0.1.7)](https://travis-ci.org/daniel-lundin/dreamfilm-xbmc)

Installation
------------
Download the plugin.video.dreamfilm-x.x.x.zip from the release section. The zip file can be installed from the add-on manager.

Issues
------
Please check that the video/serie works on dreamfilmhd.org before reporting issues.
